#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

void * mythreadFun(void * arg) {
    int * i = (int *)arg;
    
    
    printf("Thread: %lu Passed: %d\n",pthread_self(),i);
    for (int j = 0; j < i; j++) {
        printf("%d: %d\n",i,j);
    }
    printf("Thread: %lu Finished with: %d\n",pthread_self(),i);


    return 0;

}

int main() {

    

    //pthread_t tid[10];
    
    pthread_t tid[5];
    

    for (int i=0; i<5; i++) {
        printf("Before Thread...\n");
        pthread_create(&tid[i],NULL,mythreadFun,(void *)(i*100)); 
        printf("After creating thread...\n");
    }

    for (int i=0; i<5; i++) {
        printf("waiting on %lu...\n",tid[i]);
        int status = 0;
        pthread_join((tid[i]),(void *)&status);
        printf("Thread: %lu returned code: %d\n",tid[i],status);
    }

    


   



}