#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

int balance = 15000;

void withdraw(double amt) {
    if (balance - amt >= 0) {
        balance = balance - amt;
    }    
}


void * mythreadFun(void * arg) {
    

    withdraw(2);
    
}

int main() {

    //need a counter for loops
    int n = 1000;
    //need thread IDs
    pthread_t tid[n];
    
    printf("balance: %d\n",balance);


    //create and start the threads
    for (int i = 0; i<n; i++) {
        tid[i] = 0;
        //printf("< before Thread %d...\n",i);
        pthread_create(&tid[i],NULL,mythreadFun,NULL); 
        //printf("...after creating thread >\n");
        
    }

    
    printf("All done creating threads... now let's wait!\n");
    //now go and wait on threads!
    for (int i = 0; i<n; i++) {
        pthread_join((tid[i]),NULL);

        
    }

    //printf("%d should be %d\n",counter,n);

    printf("%d should be %d",balance, 0);
    



}