#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <string.h>

void searchForFileContents(char * fn, char * searchString, int recursive);

int main() {
    //give me a directory
    char fn[] = "/home/student";
    char ss[] = "state";
    //open dir
    searchForFileContents(fn,ss, 0);
    
}

void searchForFileContents(char * fn, char * searchString, int recursive) {
    //we need this struct..
    struct stat sb;
    //open directory
    DIR * dir = opendir(fn);
    //need a dirent so I can view
    struct dirent *dentry;
    //get the first one
    dentry = readdir(dir);
    while (dentry != NULL) {
        //is directory?
        char next[1000]= {0};
        //need stat (need full path though)
        //next ;
        strcat(next, fn);
        strcat(next, "/");
        strcat(next, dentry->d_name);
        stat(next,&sb);

        if ((sb.st_mode & S_IFMT) == S_IFDIR) {
            //we don't want to go back up... nor repeat here
            //so ignore if name starts with .
            if (dentry->d_name[0] != '.' ) {
                //printf("%c \n",dentry->d_name[0]);
                //printf("Directory: %s \n", next);
                //recurse
                if (recursive) {
                    searchForFileContents(next,searchString,recursive);
                }
                
                
            }
        } else if ((sb.st_mode & S_IFMT) == S_IFREG) {

            
            if (strstr(dentry->d_name,".txt") != NULL) {

                int found = 0;
                //regular file, do regular file stuff
                //next holds filename
                FILE * file = fopen(next,"r");
                //then we are going to read line by line
                char buffer[1000];

                while (fgets(buffer,1000,file) != NULL) {
                    if (strstr(buffer,searchString) != NULL) {
                        if (found == 0) {
                            printf("%s:\n", next);
                            found++;
                        }
                        printf("%s",buffer);
                    }
                    
                }
                //close file
                fclose(file);
                if (found != 0) {
                    printf("\n");
                }

            }
        }
        
        //get the next one
        dentry = readdir(dir);

    }


    //close dir
    closedir(dir);

    

}
