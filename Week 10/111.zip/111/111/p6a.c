#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>

//void searchForFileContents(char * fn, char * searchString, int recursive);

void * searchFileForContents(void * fn);
void searchDirectoryForContents(char * fn);

char * searchString = "whatwhat";

int recursive = 1;

//one thread per file...
//->diff vers one thread per directory
//->diff vers one thread per directory/file 


int counter = 0;

pthread_t tid[10000];

int main() {
    //give me a directory
    char fn[] = "/home/student";
    searchString = "state";
    //open dir
    searchDirectoryForContents(fn);

    for (int i=0; i<counter; i++) {
        printf("waiting on %ul \n", tid[i]);
        pthread_join(tid[i], NULL);
    }
    
}


void * searchFileForContents(void * fn) {
    printf("Searching File %s:\n",fn);
    /*
    int found = 0;
    //regular file, do regular file stuff
    //next holds filename
    FILE * file = fopen(fn,"r");
    //then we are going to read line by line
    char buffer[1000];

    while (fgets(buffer,1000,file) != NULL) {
        if (strstr(buffer,searchString) != NULL) {
            if (found == 0) {
                printf("%s:\n", fn);
                found++;
            }
            printf("%s",buffer);
        }
                        
    }
    //close file
    fclose(file);
    if (found != 0) {
        printf("\n");
    }
    */
}



void searchDirectoryForContents(char * fn) {
    printf("Searching in Dir: %s:\n",fn);
    
    
    //open directory
    DIR * dir = opendir(fn);
    //need a dirent so I can view
    struct dirent *dentry;
    //get the first one
    dentry = readdir(dir);
    while (dentry != NULL) {
        //is directory?
        //char * next = (char *)malloc(sizeof(char)*1000);
        char next[1000]= {0};
        //need stat (need full path though)
        //next ;
        strcat(next, fn);
        strcat(next, "/");
        strcat(next, dentry->d_name);
        
        
        if (dentry->d_type == DT_DIR) {
            if (dentry->d_name[0] != '.' ) {
                
                printf("Directory: %s \n", next);
                //recurse
                if (recursive) {
                    
                    searchDirectoryForContents(next);
                }
            }
        }

        
        //get the next one
        dentry = readdir(dir);
        
    }


    //close dir
    closedir(dir);

    //join them here

}
