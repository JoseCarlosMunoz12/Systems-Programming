#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>


void * mythreadFun2(void *arg) {
    char * s = (char *)arg;
    printf("Thread: %lu Passed: %s\n",pthread_self(),s);
    printf("strlength of %s is %d\n",s, strlen(s));
    
    return (void*)strlen(s);
}

void * mythreadFun(void * arg) {
    char * s = (char *)arg;
    //int * threadID = (int*)arg;
    printf("Thread: %lu Passed: %s\n",pthread_self(),s);
    free(arg);
    return (void*)strlen(s);

}

int main() {

    

    pthread_t tid[10];
    char * sarray[] = {"Will",
                      "the",
                      "real", 
                      "slim",
                      "shady",
                      "please",
                      "stand",
                      "up?",
                      "-",
                      "Eminem"};

    

    for (int i = 0; i<10; i++) {
        tid[i] = 0;
        char * fn = (char *)malloc(sizeof(char) * 100);
        strcpy(fn,sarray[i]);
        
        //printf("Before Thread...\n");
        printf("Creating thread for: %s\n",fn);
        pthread_create(&tid[i],NULL,mythreadFun2,(void *)fn); 
        //printf("After creating thread...\n");
    }
    //now go and wait on threads!
    for (int i = 0; i<10; i++) {
        int status = 0;
        pthread_join((tid[i]),(void *)&status);

        printf("Thread: %lu returned code: %d\n",tid[i],status);
    }

    //sleep(10);
   



}