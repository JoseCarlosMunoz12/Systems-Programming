#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>


void * mythreadFun2(void *arg) {
    sleep(5);
    printf("Hello, I am Thread: %lu \n",pthread_self());
 
}

int main() {
        //need a tid
        pthread_t tid = 0;

        printf("Creating thread...\n");
        pthread_create(&tid,NULL,mythreadFun2,NULL); 
        //printf("After creating thread...\n");
        //pthread_detach(tid);
        pthread_join(tid,NULL);
        sleep(1);



}