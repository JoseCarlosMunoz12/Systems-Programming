#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

long counter = 0;


void * counterThread(void *arg) {

    for (int i=0; i<10000000; i++) {
        counter++;
    }
  
    printf("Hello, I am Thread: %lu and my count is %d\n",pthread_self(),counter);

}



int main() {


        pthread_t tids[3];
        

        for (int i=0; i<3; i++) {
            printf("Creating thread...\n");
            //create the thread
            pthread_create(&tids[i],NULL,counterThread,NULL); 
        }

        for (int i=0; i<3; i++) {
            //join the thread
            pthread_join(tids[i],NULL);
        }
        
        



}