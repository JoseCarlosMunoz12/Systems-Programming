#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

long counter = 0;
//create our lock!
pthread_mutex_t lock1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t lock2 = PTHREAD_MUTEX_INITIALIZER;


void * methodOne(void* arg) {
     for (int i=0; i<1000000; i++) {
          pthread_mutex_lock(&lock1);
          pthread_mutex_lock(&lock2);

          printf("I'm doing something useful");

          pthread_mutex_unlock(&lock2);
          pthread_mutex_unlock(&lock1);
     }
    
}


void * methodTwo(void* arg) {
    for (int i=0; i<1000000; i++) {

          pthread_mutex_lock(&lock2);
          pthread_mutex_lock(&lock1);

          printf("I'm doing something useful\n");

          pthread_mutex_unlock(&lock1);
          pthread_mutex_unlock(&lock2);
     }
}




int main() {


        pthread_t tid1, tid2;
        

        
        printf("Creating thread...\n");
        //create the thread
        pthread_create(&tid1,NULL,methodOne,NULL); 
        printf("Creating thread...\n");
        //create the thread
        pthread_create(&tid2,NULL,methodOne,NULL);
        

        pthread_join(tid1,NULL);
        pthread_join(tid2,NULL);
        
        



}