#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>

void processIntSignal(int signo);

int main() {

    pid_t pid = fork();

    if (pid != 0) {
        printf("Parent: P: %d PP: %d\n",getpid(),getppid());
        //go to sleep    
        sleep(2);
        
        
        //send signal
        kill(pid,SIGINT);
        //sleep
        sleep(1);
        //send signal
        kill(pid,SIGUSR1);
        //sleep
        sleep(1);
        //send signal
        kill(pid,SIGTERM);
        wait(NULL);
    } else {
        //parent:
        printf("Child: P: %d PP: %d\n",getpid(),getppid());
        //set up SIGINT processor
        signal(SIGINT,processIntSignal);
        signal(SIGUSR1,processIntSignal);
        signal(SIGTERM,processIntSignal);
        printf("ready for signals\n");

        //go to sleep
        sleep(1);
        sleep(1);
        sleep(1);
        sleep(1);
        sleep(1);
        //wait on child
        printf("Done");
        
    }




}

extern const char * const sys_siglist[];

void processIntSignal(int signo) {
    //need a string
    const char *s = strsignal(signo);
    //print out which signal
    printf("Signal: %s was received... \n",s);


    if (signo == SIGINT) {
        printf("SIGINT Received: %d\n",signo);
    } else if (signo == SIGUSR1) {
        printf("SIGUSR1 Received: %d\n",signo);
    } else if (signo == SIGTERM) {
        printf("SIGTERM Received: %d\n",signo);
    }


    
}