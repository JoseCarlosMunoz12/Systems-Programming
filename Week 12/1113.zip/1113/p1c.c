#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>

//extern const char * const sys_siglist[];

int main() {

    for (int i=0; i<50; i++) {
        printf("%d => %s\n",i, strsignal(i));
    }


}

