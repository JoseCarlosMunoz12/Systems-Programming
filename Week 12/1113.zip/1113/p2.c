#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>

void processIntSignal(int signo);

int main() {

    printf("Parent: P: %d PP: %d\n",getpid(),getppid());
    //set up SIGINT processor
    signal(SIGINT,processIntSignal);

    for (int i=0; i<10; i++) {
        sleep(3);
        printf("Waking up? nah!\n");
    }




}

void processIntSignal(int signo) {
    printf("SIGINT Received: %d\n",signo);
}