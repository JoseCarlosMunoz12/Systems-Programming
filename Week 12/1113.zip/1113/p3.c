#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>

void processIntSignal(int signo);
//global variable
int count = 0;

int main() {

    printf("Parent: P: %d PP: %d\n",getpid(),getppid());
    //set up SIGINT processor
    signal(SIGINT,processIntSignal);

    while (0==0);




}


void processCleanup() {
    printf("cleaning up...\n");
}

void processIntSignal(int signo) {
    //increment local variable
    count++;
    //if not too many?
    if (count < 3) {
        printf("SIGINT Received: %d\n",count);
    } else {
        //we're going to fail!
        printf("We received too many SIGINTS\n");
        //this seems right... but isn't...
        //raise(SIGKILL);
        processCleanup();
        exit(-1);

    }
    
    
}