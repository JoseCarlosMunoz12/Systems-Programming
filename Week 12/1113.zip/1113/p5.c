#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdlib.h>

void processIntSignal(int signo);

int count = 0;

int main() {

    printf("Parent: P: %d PP: %d\n",getpid(),getppid());
    //set up SIGINT processor
    signal(SIGINT,SIG_IGN);

    while (0==0);

}

void processIntSignal(int signo) {
    count++;
    if (count < 4) {
        printf("SIGINT Received: %d\n",count);
    } else {
        printf("We received too many SIGINTS\n");
        //this is what you actually want...
        exit(-3);

    }
    
    
}