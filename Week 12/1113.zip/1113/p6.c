#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdlib.h>

void processIntSignal(int signo);

int count = 0;

int main() {

    printf("Parent: P: %d PP: %d\n",getpid(),getppid());
    //set up SIGINT processor
    signal(SIGINT,processIntSignal);

    //we need a set
    sigset_t blockSigs;
    //we need the empty set
    sigemptyset(&blockSigs);
    //add SIGINT
    sigaddset(&blockSigs,SIGINT);
    //block them
    

    while (0 == 0) {
        printf("Blocking SIGINT\n");
        sigprocmask(SIG_BLOCK,&blockSigs,NULL);
        printf("going to sleep...\n");
        sleep(10);
        printf("Wake...\n");
        printf("Unblocking SIGINT\n");
        sigprocmask(SIG_UNBLOCK,&blockSigs,NULL);
    }





}

void processIntSignal(int signo) {
    count++;
    if (count < 4) {
        printf("SIGINT Received: %d\n",count);
    } else {
        printf("We received too many SIGINTS\n");
        //this is what you actually want...
        exit(-3);

    }
    
    
}