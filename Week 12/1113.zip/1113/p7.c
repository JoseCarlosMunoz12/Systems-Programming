#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdlib.h>

void processIntSignal(int signo);

int count = 0;

int main() {

    printf("Parent: P: %d PP: %d\n",getpid(),getppid());
    //set up SIGINT processor
    signal(SIGINT,processIntSignal);

    //we need a set
    sigset_t blockSet;
    //we need the oldset
    sigset_t oldSet;
    //we need the empty set
    sigemptyset(&blockSet);
    //add SIGINT
    sigaddset(&blockSet,SIGINT);
    //block them
    printf("Blocking SIGINT\n");
    sigprocmask(SIG_BLOCK,&blockSet,&oldSet);

    while (0 == 0) {
        
        
        printf("going to sleep...\n");
        sleep(3);
        printf("Wake...\n");
        printf("Now going to wait for a signal...\n");
        sigsuspend(&oldSet);
    }





}

void processIntSignal(int signo) {
    count++;
    if (count < 4) {
        printf("SIGINT Received: %d\n",count);
    } else {
        printf("We received too many SIGINTS\n");
        //this is what you actually want...
        exit(-3);

    }
    
    
}