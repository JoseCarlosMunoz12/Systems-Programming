#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <time.h>

int main() {

    time_t start = clock();

    for (int i=0; i<100000; i++) {
        printf("i: %d\n",i);
    }

    time_t end = clock();

    printf("Time: %f\n", ((double)(end-start))/CLOCKS_PER_SEC);




}


