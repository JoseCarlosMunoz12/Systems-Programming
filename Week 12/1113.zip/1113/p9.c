#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdlib.h>


int main() {

    char* s = malloc(sizeof(char)*80);

    FILE * input = popen("find /home/student -name '*.png'","r");

    int line = 0;

    while (fgets(s, 80, input) != NULL) {
        if (line != 0) {
            printf("%s",s);
        }
        line++;
        
    }


}