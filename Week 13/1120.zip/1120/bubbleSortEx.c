// C program for implementation of Bubble sort
#include <stdio.h>
 
void bubbleSort(int arr[], int n);

int main() {
    
    int array[10];
    //seed the random ng with right now
    srand(time(NULL));

    for (int i=0; i<10; i++) {
        array[i] = 1 + rand() % 6; 
    }

    for (int i=0; i<10; i++) {
        printf("Array element [%d] = %d\n",i,array[i]); 
    }

    bubbleSort(10, array);

    printf("Sorted...\n");
    for (int i=0; i<10; i++) {
        printf("Array element [%d] = %d\n",i,array[i]); 
    }
    
}



void swap(int* xp, int* yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}
 
// A function to implement bubble sort
void bubbleSort(int arr[], int n)
{
    int i, j;
    for (i = 0; i < n - 1; i++)
 
        // Last i elements are already in place
        for (j = 0; j < n - i - 1; j++)
            if (arr[j] > arr[j + 1])
                swap(&arr[j], &arr[j + 1]);
}
 


