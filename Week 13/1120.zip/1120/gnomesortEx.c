#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void gnomesort(int n, int array[]);

int main() {
    
    int array[10];
    //seed the random ng with right now
    srand(time(NULL));

    for (int i=0; i<10; i++) {
        array[i] = 1 + rand() % 6; 
    }

    for (int i=0; i<10; i++) {
        printf("Array element [%d] = %d\n",i,array[i]); 
    }

    gnomesort(10, array);

    printf("Sorted...\n");
    for (int i=0; i<10; i++) {
        printf("Array element [%d] = %d\n",i,array[i]); 
    }
    
}

void gnomesort(int n, int array[]) {

    int pos = 0;
    //while there are pots to compare
    while (pos < n) {
        //printf("position: %d\n",pos);
        //what do depends on positions
        if (pos == 0) {
            //nothing behind you
            //move forward
            pos++;
        } else if (array[pos] >= array[pos - 1]) {
            
            //they're in order, so move forward
            pos++;
        } else {
            //they're not in order
            //swap
            int temp = array[pos-1];
            array[pos-1] = array[pos];
            array[pos] = temp;

            //back up
            pos--;
        }



    }


}

