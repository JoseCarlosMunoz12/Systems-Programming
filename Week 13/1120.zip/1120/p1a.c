#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {

    time_t val;
    long seconds = (long)time(&val);

    printf("Time: %ld\n",seconds);

    printf("Time: %s\n", ctime(&val));

    val = val + (30 * 24 * 60 * 60);

    printf("Exam Time: %s\n", ctime(&val));

    struct tm * now;

    now = localtime(&val);
    //need a string buffer
    char str[80];
    char strend[80];
    //exactly like ctime
    char * postfix;
    //size_t size = strftime(str,80,"%a %b %d %X %Y",now);
    int day = now->tm_mday;
    //figure out if ends with
    int endswith = day % 10;
    if (endswith == 1) {
        postfix = "st";
    } else if (endswith == 2) {
        postfix = "nd";
    } else if (endswith == 3) {
        postfix = "rd";
    } else {
        postfix = "th";
    }
    
    
    printf("%d/7 %d/%d\n", now->tm_wday,(now->tm_mon)+1,now->tm_mday);
    now->tm_mday = now->tm_mday + 16;
    printf("%d/7 %d/%d\n", now->tm_wday,(now->tm_mon)+1,now->tm_mday);

    //st, nd, rd, th
    size_t size = strftime(str,80,"Date: %B %d",now);
    size_t size2 = strftime(strend,80,", %Y",now);

    printf("%s%s%s\n",str,postfix,strend);

    
}
