#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {

    clockid_t clocks[] = {
        CLOCK_REALTIME,
        CLOCK_REALTIME_ALARM,
        CLOCK_REALTIME_COARSE,
        CLOCK_MONOTONIC,
        CLOCK_MONOTONIC_COARSE,
        CLOCK_MONOTONIC_RAW,
        CLOCK_PROCESS_CPUTIME_ID, 
        CLOCK_THREAD_CPUTIME_ID,
    };

    struct timespec res;

    for (int i=0; i<8; i++) {
        int ret;
        ret = clock_getres(clocks[i], &res);

        if (ret == 0) {
            printf("clock=%d sec=%ld nsec=%ld\n", clocks[i],res.tv_sec, res.tv_nsec);
        }
    }

    
}
