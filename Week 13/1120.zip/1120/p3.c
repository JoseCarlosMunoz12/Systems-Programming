#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {

    struct timespec res1;
    struct timespec res2;
    int ret = clock_gettime(CLOCK_REALTIME, &res1);

    


    
    ret = clock_gettime(CLOCK_REALTIME, &res2);
    
    printf("Time: %s\n", ctime(&res1.tv_sec));


    printf("sec=%ld nsec=%ld\n", res1.tv_sec, res1.tv_nsec);
    printf("sec=%ld nsec=%ld\n", res2.tv_sec, res2.tv_nsec);

    printf("Difference: sec=%ld nsec=%ld\n", res2.tv_sec-res1.tv_sec, res2.tv_nsec-res1.tv_nsec);

}
