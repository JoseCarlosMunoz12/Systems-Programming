#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>

void alarm_handler(int signo) {
    time_t val;
    long seconds = (long)time(&val);
    printf("Time: %s\n", ctime(&val));
    printf("Did 1 second pass already?\n");
    sync();
}

int main() {
    struct itimerval delay;
    signal(SIGALRM, alarm_handler);
    delay.it_value.tv_sec = 1;
    delay.it_value.tv_usec = 0;
    delay.it_interval.tv_sec = 1;
    delay.it_interval.tv_usec = 0;

    setitimer(ITIMER_REAL, &delay, NULL);

    pause();
    pause();
    pause();
    pause();
    
}
