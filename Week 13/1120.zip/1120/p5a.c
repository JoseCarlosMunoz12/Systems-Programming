#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>

int counter = 0;

void alarm_handler(int signo) {
    time_t val;
    long seconds = (long)time(&val);
    printf("Time: %s\n", ctime(&val));
    printf("Did 2 seconds pass already?\n");
    fflush(stdout);
    
    if (counter > 5) {
        printf("Too many alarms");
        exit(0);
    } else {
        counter++;
    }
    
}

int main() {
    struct itimerval delay;
    signal(SIGALRM, alarm_handler);
    delay.it_value.tv_sec = 2;
    delay.it_value.tv_usec = 0;
    delay.it_interval.tv_sec = 2;
    delay.it_interval.tv_usec = 0;

    setitimer(ITIMER_REAL, &delay, NULL);

    while (0==0);
    
}
