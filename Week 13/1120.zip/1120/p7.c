#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void bubbleSort(int n, int arr[]);
void gnomesort(int n, int array[]);

int main() {

    





    int times = 30;
    struct timespec res1;
    struct timespec res2;

    long sum = 0;

    for (int i=0; i<times; i++) {

        int array[100];
        //seed the random ng with right now
        srand(time(NULL));

        for (int i=0; i<100; i++) {
            array[i] = 1 + rand() % 100; 
        }


        int ret = clock_gettime(CLOCK_REALTIME, &res1);

        //here is what we're timing...
        //gnomesort(10, array);
        bubbleSort(100, array);
    
        ret = clock_gettime(CLOCK_REALTIME, &res2);

        /*
        printf("Sorted...\n");
        for (int i=0; i<10; i++) {
            printf("Array element [%d] = %d\n",i,array[i]); 
        }
        */
        //printf("Time: %s\n", ctime(&res1.tv_sec));


       // printf("sec=%ld nsec=%ld\n", res1.tv_sec, res1.tv_nsec);
       // printf("sec=%ld nsec=%ld\n", res2.tv_sec, res2.tv_nsec);

        printf("Difference: sec=%ld nsec=%ld\n", res2.tv_sec-res1.tv_sec, res2.tv_nsec-res1.tv_nsec);
        sum = sum + (res2.tv_nsec-res1.tv_nsec);
    }

    printf("After %d times, we average: %.2f",times,sum/(double)times);

}

void swap(int* xp, int* yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}
 
// A function to implement bubble sort
void bubbleSort(int n, int arr[])
{
    int i, j;
    for (i = 0; i < n - 1; i++)
 
        // Last i elements are already in place
        for (j = 0; j < n - i - 1; j++)
            if (arr[j] > arr[j + 1])
                swap(&arr[j], &arr[j + 1]);
}

void gnomesort(int n, int array[]) {

    int pos = 0;
    //while there are pots to compare
    while (pos < n) {
        //printf("position: %d\n",pos);
        //what do depends on positions
        if (pos == 0) {
            //nothing behind you
            //move forward
            pos++;
        } else if (array[pos] >= array[pos - 1]) {
            
            //they're in order, so move forward
            pos++;
        } else {
            //they're not in order
            //swap
            int temp = array[pos-1];
            array[pos-1] = array[pos];
            array[pos] = temp;

            //back up
            pos--;
        }



    }


}
