#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/stat.h>

#define PORT 7777

int main(int argc, char * argv[]) {
    //really simple client that handles the puking...
    //we're going to assume that we always go for 127.0.0.1
    //so we're only asking for port
    //we need a port
    int port = 0;
    //we're going to "maybe" receive a port number
    if (argc > 1) {
        //grab port number from 1st arg
        port = atoi(argv[1]);
    } else {
        //otherwise get it from PORT
        port = PORT;
    }

    
    //new connection socket descripter
    int serverSD;
    //My address
    struct sockaddr_in server;
    
    //size of addresses :)
    int size_server;
    //set the family
    server.sin_family = AF_INET;
    //set the port (host to network)
    server.sin_port = htons(port);
    //set the address (string to inet_addr_t)
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    
    //allocate a free socket!
    serverSD = socket(AF_INET,SOCK_STREAM,0);
    //all good?
    if (serverSD < 0) {
        perror("Socket Allocation failed!\n");
        exit(-3);
    }

    /* NOW we need to connect.. looks a lot like accept() */
    int ret = connect(serverSD,(struct sockaddr *)&server, sizeof(server));

    //since we read and write... lets do the same
    FILE * in = fdopen(STDIN_FILENO,"r");
    //now for the server (we can open two!)
    FILE * serverOut = fdopen(serverSD,"w");
    FILE * serverIn = fdopen(serverSD, "r");

    char lineFromServer[256];
    char line[256];
    //read a sginle line from the server
    fgets(line, sizeof(line),serverIn);
    //print
    printf("%s", line);
    /*
    //continually read lines until either EOF
    while (fgets(line,sizeof(line),in) != NULL) {
        //stop if quit is encountered
        if (strncmp(line,"quit",4) == 0) {
            //send quit and break!
            fputs("quit\n",serverOut);
            //after write, flush!
            fflush(serverOut);
            //bug out!
            break;
        } else {
            //write out line...
            fputs(line,serverOut);
            //after write, flush!
            fflush(serverOut);
            //now that we wrote, let's wait for a writeback
            fgets(line,sizeof(line),serverIn);
            //now that we have it, print it out
            printf("%s",line);
                
        }
    } */

    //close fds
    fclose(in);
    fclose(serverIn);
    fclose(serverOut);
    //close server SD
    close(serverSD);


}