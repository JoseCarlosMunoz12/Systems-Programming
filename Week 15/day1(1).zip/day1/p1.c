#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>

#define PORT 7777
#define MOTD "Hello World!\n"

int main() {
    
    //socket descriptor
    int sd;
    //new connection socket descripter
    int connSD;
    //My address
    struct sockaddr_in sa;
    //client address
    struct sockaddr_in ca;
    //size of client address
    int size_ca;

    //use IA family
    sa.sin_family = AF_INET;
    //copy port number
    //NOTE: must translate to network byte order
    sa.sin_port = htons(PORT);
    //accept connections from anywhere
    //we use to limit where conns can come from
    sa.sin_addr.s_addr = INADDR_ANY;
    
    

    //allocate a free socket
    sd = socket(AF_INET, SOCK_STREAM,0);
    //did it work?
    if (sd < 0) {
        perror("Socket: Allocation failed!");
    }

    //now bind the socket to our address
    int ret = bind(sd, (struct sockaddr *)&sa, sizeof(sa));
    //check
    if (ret) {
        perror("Binding Failed");
    }

    /* now, let's ask the system to listen for incoming connections
       to the address we just bound...  specify that up to 5 
       pending connection requests will be queued by the system
       if we're not directly awaitng them using the accept() system
       call when they arrive
    */
    ret = listen(sd, 5);
    //check for error
    if (ret) {
        perror("Listen Failure");
    }
    //we'll need the size for later
    size_ca = sizeof(ca);
    //forever loop
    while (0 == 0) {
        //the accept() call will wait for a connection
        //when one is established, a new socket will be
        //created to form it... the ca var will hold the 
        //address of the client that just connected
        //the old socket sd will still be available for
        //future accept() statements
        connSD = accept(sd, (struct sockaddr *)&ca, &size_ca);
        //check for errors, 
        if (connSD < 0) {
            //reenter accept()
            continue;
        }
        //we have a functioning socket, so do something
        write(connSD, MOTD,sizeof(MOTD));
        //now we're done, so close
        close(connSD);


    }

}