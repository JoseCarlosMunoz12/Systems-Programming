#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <ctype.h>
#define PORT 7777
#define MOTD "Hello World!\n"
#define UPPER 1
#define LOWER 2
#define MIXED 3



int main() {
    
    //socket descriptor
    int sd;
    //new connection socket descripter
    int connSD;
    //My address
    struct sockaddr_in sa;
    //client address
    struct sockaddr_in ca;
    //size of client address
    int size_ca;

    //use IA family
    sa.sin_family = AF_INET;
    //copy port number
    //NOTE: must translate to network byte order
    sa.sin_port = htons(PORT);
    //accept connections from anywhere
    //we use to limit where conns can come from
    sa.sin_addr.s_addr = INADDR_ANY;
    
    //allocate a free socket
    sd = socket(AF_INET, SOCK_STREAM,0);
    //did it work?
    if (sd < 0) {
        perror("Socket: Allocation failed!");
    }

    //now bind the socket to our address
    int ret = bind(sd, (struct sockaddr *)&sa, sizeof(sa));
    //check
    if (ret) {
        perror("Binding Failed");
    }

    /* now, let's ask the system to listen for incoming connections
       to the address we just bound...  specify that up to 5 
       pending connection requests will be queued by the system
       if we're not directly awaitng them using the accept() system
       call when they arrive
    */
    ret = listen(sd, 5);
    //check for error
    if (ret) {
        perror("Listen Failure");
    }

    
    //we want the listening output to be more accurate
    char hostBuffer[255];
    struct hostent *host_entry;
    int hostname;

    //retrieve hostname
    hostname = gethostname(hostBuffer,sizeof(hostBuffer));
    //get host by name
    host_entry = gethostbyname(hostBuffer);
    //check for it being null
    if (host_entry != NULL) {
        //get the list of addresses
        char ** addressList = host_entry->h_addr_list;
        //the list above is NULL terminated... so...
        //loop through them
        while (*addressList != NULL) {
            //get the IP address
            char * address = inet_ntoa(*(struct in_addr *)*addressList);
            //print
            printf("Listening on IP %s on port %d\n",address,ntohs(sa.sin_port));
            addressList++;
        }

    } else {
        //it's null so do what we did before
        //now that we have a socket, let's display the socket
            //and port number like: xxx.xxx.xxx.xxx:pppp
            char * address = inet_ntoa(sa.sin_addr);
            //now print
            printf("Listening on IP %s on port %d\n",address,ntohs(sa.sin_port));
    }

    //we'll need the size for later
    size_ca = sizeof(ca);
    //forever loop
    while (0 == 0) {
        //the accept() call will wait for a connection
        //when one is established, a new socket will be
        //created to form it... the ca var will hold the 
        //address of the client that just connected
        //the old socket sd will still be available for
        //future accept() statements
        connSD = accept(sd, (struct sockaddr *)&ca, &size_ca);
        //check for errors, 
        if (connSD < 0) {
            //reenter accept()
            continue;
        }
        //now we have client...
        char * clientAddress = inet_ntoa(ca.sin_addr);
        //now print
        printf("Client connected from IP %s and port %d\n",clientAddress,ntohs(ca.sin_port));
        //we have a functioning socket, so do something
        FILE * file = fdopen(connSD,"r");


        int state = 0;
        int statechange = 0;

        char line[256];
        //continually read lines until either EOF
        while (fgets(line,sizeof(line),file) != NULL) {
            printf("Line: %s\n", line);
            //stop if quit is encountered
            if (strncmp(line,"quit",4) == 0) {
                break;
            } else if (strncmp(line,"upper",4) == 0) {
                state = UPPER;
                printf("Upper:\n");
                statechange = 1;
            } else if (strncmp(line,"lower",4) == 0) {
                state = LOWER;
                printf("Lower:\n");
                statechange = 1;
            } else if (strncmp(line,"mixed",4) == 0) {
                state = MIXED;
                printf("MIXED\n");
                statechange = 1;
            
            } 

                if (statechange) {
                    //do nothing
                    printf("State changed...\n");
                    char ret[256] = "ok\n";
                    printf("should output: %s\n",ret);
                    statechange = 0;
                    write(connSD, ret,strlen(ret));
                    

                } else {
                    printf("State did not change...\n");
                    //we need the length of the string
                    int len = strlen(line);
                    //let's have some fun
                    if (state == UPPER) {
                        //make upper case
                        for (int i=0; i<len; i++) {
                            line[i] = toupper(line[i]);
                        }
                    } else if (state == LOWER) {
                        //make lower case
                        for (int i=0; i<len; i++) {
                            line[i] = tolower(line[i]);
                        }
                    } else if (state == MIXED) {
                        //make mixed case
                        for (int i=0; i<len; i++) {
                            if (i % 2 == 0) {
                                line[i] = toupper(line[i]);
                            } else {
                                line[i] = tolower(line[i]);
                            }
                                
                        }
                        
                    } 
                    //write out line...
                    write(connSD, line,strlen(line));

                    
                }

                
            
            
        }
        //we should close the fdopen...
        fclose(file);
        //and then close the socket
        close(connSD);


    }

}