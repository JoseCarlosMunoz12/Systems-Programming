#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <sys/time.h>
#include <ctype.h>
#include <pthread.h>

void * processClient(void * arg) {

    int connSD = *(int*)arg;

    printf("Client Socket Descriptor is %d\n", connSD);

    
    
}

int main() {


    pthread_t tids[10];

    for (int i=0; i<10; i++) {
        int * mySD = malloc(sizeof(int));
        *mySD = i;

        
        pthread_create(&tids[i], NULL, processClient, mySD);

    }

    for (int i=0; i<10; i++) {
        pthread_join(tids[i],NULL);
    }

}