#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pwd.h>
#include <fnmatch.h>

int getTypeId(const char* type);

void SearchDirectory(const char* dirPath, const char* name, int doRecursive, int uID, int type,int sizeflag, int size, int depth);

void DisplayParameters();

int main(int argc, char *argv[])
{
    if(argc < 2){
        //displays options for the directory path.
        DisplayParameters();
        return 0;
    }
    int doRecursive = 0;
    int uID = -1;
    int type = -1;
    int recursiveDepth = -1;
    char *name = NULL;
    char *path = NULL;
    int size;
    int sizeFlag = -1;
    for(int ii = 1; ii < argc; ii++){
        if(strcmp(argv[ii], "-name") ==0){
            if((ii + 1 ) < argc){
                ii++;
                name = argv[ii];
            }
        } else if (strcmp(argv[ii],"-R") == 0){
            doRecursive = 1;
        } else if (strcmp(argv[ii], "-uid") == 0){
            if((ii + 1) < argc)
            {
                ii++;
                uID = atoi(argv[ii]);
            }
        } else if (strcmp(argv[ii], "-type") == 0){
            if((ii + 1) < argc)
            {
                ii++;
                uID = getTypeId(argv[ii]);
            }
        } else if (strcmp(argv[ii], "-depth") == 0){
            if((ii + 1) < argc){
                ii++;
                recursiveDepth = atoi(argv[ii]);
            }
        } else if (strcmp(argv[ii], "-eq") == 0){
            if((ii + 1) < argc){
                ii++;
                sizeFlag = 2;
                size = atoi(argv[ii]);
            }
        } else if (strcmp(argv[ii], "-gt") == 0){
            if((ii + 1) < argc){
                ii++;
                sizeFlag = 1;
                size = atoi(argv[ii]);
            }
        } else if (strcmp(argv[ii], "-lt") == 0){
            if((ii + 1) < argc){
                ii++;
                sizeFlag = 0;
                size = atoi(argv[ii]);
            }
        } else {
             path = argv[ii];
        }
    }
    //if no path was set, then end program and show parameters to add
    if (path == NULL){
        printf("The directory path is NULL!!\nPlease Enter a valid path.\n");
        DisplayParameters();
        return 0;
    }
    SearchDirectory(path, name ,doRecursive, uID, type, sizeFlag, size, recursiveDepth);
    return 0;
}

void SearchDirectory(const char* dirPath, const char* name, int doRecursive, int uID, int type,int sizeFlag, int size, int depth){
    
    //first check if recurisive limit is met. ie, depth = 0, if depth = -1, it won't do a depth check
    if(depth >= 0){
        if(depth == 0)
            return;
    }
    //open directory if possible, otherwise returns
    DIR *dir = opendir(dirPath);
    if(dir == NULL){
        return;
    }
    struct dirent *dirInfo;
    //find all files in the directory
    while((dirInfo = readdir(dir)) != NULL){
        //ignore "." and ".." directory
        if(strcmp(dirInfo->d_name,".") != 0 && strcmp(dirInfo->d_name, "..") != 0){
            //get full path of the file and stat of the file.
            struct stat fileStats;            
            char *newPath = malloc(sizeof(char) * 250);
            strcpy(newPath,dirPath);
            strcat(newPath,"/");
            strcat(newPath,dirInfo->d_name);        
            int res = stat(newPath,&fileStats);
            if(res == -1){
                printf("ERROR! Unable to get stats of file!\n");
                continue;
            }
            //flag to see if the user want to find based on uiID, if uid not found, continue search
            if(uID != -1 && fileStats.st_uid != uID)
                continue;
            //flag to see if the user want to check type, if type not found, continue search
            if (type > -1 && dirInfo->d_type != type)
                continue;
            //flag to see if the user wants to check the file Name type. If not found, continue search
            if(name != NULL && strstr(dirInfo->d_name, name) == NULL)
                continue;
            //flag to see if the user wants to check the file bit size check, if not continue search
            //Flags -1, do no search, 0, check for lt. 1, chek for gt. 2 check for et
            if (sizeFlag != -1)
            {
                if(sizeFlag = 0){
                    if(fileStats.st_size >= size)
                        continue;

                }else if (sizeFlag == 1){
                    if(fileStats.st_size <= size)
                        continue;
                    
                } else if (sizeFlag == 2){
                    if(fileStats.st_size != size)
                        continue;
                }
            }
            printf("%s/%s\n",dirPath,dirInfo->d_name);
            if(doRecursive){
                SearchDirectory(newPath ,name, doRecursive ,uID, type,sizeFlag ,size ,depth - 1);
            }
        }
    }
    closedir(dir);
}


int getTypeId(const char* type){
    if (strcmp(type, "d") == 0)
        return DT_DIR;
    else if (strcmp(type, "f") == 0)
        return DT_REG;
    else if (strcmp(type, "b") == 0)
        return DT_BLK;
    else if (strcmp(type, "c") == 0)
        return DT_CHR;
    else if (strcmp(type, "p") == 0)
        return DT_FIFO;
    else if (strcmp(type, "l") == 0)
        return DT_LNK;
    else if (strcmp(type, "s") == 0)
        return DT_SOCK;
    return -1;
}

void DisplayParameters(){
    printf("Usage: file_search [Parameters] directory_path\n");
    printf("Parameters:\n");
    printf("  -name <name>: Search for files/directories that has this name.\n");
    printf("  -R: Does a a recursive search.\n");
    printf("  -uid <uid>: Searches for files that have a specifici uid.\n");
    printf("            : d for a directory file.\n");
    printf("            : f for a regular file.\n");
    printf("            : b for a block fle.\n");
    printf("            : c for a character device file.\n");
    printf("            : p is for a pip file.\n");
    printf("            : l for a link file.\n");
    printf("            : s for a socket file.\n");
    printf("  -lt <size> searches for files that are less than <size>.\n");
    printf("  -gt <size> searches for files that are less than <size>.\n");
    printf("  -qt <size> searches for files that are less than <size>.\n");
    printf("  -depth <depth>: If doing a recursive, This will be the limit depth that it can find files.\n");

}