#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
///
/// Does the same application as the forkmain, only that it doesn't use fork for recursive search
///

void printDirectory(const char* dirPath);

int main(int argc, char* argv[]){
    if(argc != 2)
    {
        return 0;
    }
    printDirectory(argv[1]);
    return 0;
}
void printDirectory(const char* dirPath){
    DIR *dir = opendir(dirPath);
    if(dir == NULL){
        return;
    }
    struct dirent * dirInfo;
    while((dirInfo = readdir(dir)) != NULL){
        if(strcmp(dirInfo->d_name,".") != 0 && strcmp(dirInfo->d_name,"..") != 0){
            struct stat stats;            
            char *newPath = malloc(sizeof(char) * 256);
            strcpy(newPath,dirPath);
            strcat(newPath,"/");
            strcat(newPath,dirInfo->d_name); 
            int res = stat(newPath,&stats);
            //Checks if the file is a regular file
            if(S_ISREG(stats.st_mode)){
                printf("%s\n", newPath);
            } else if(S_ISDIR(stats.st_mode)){//Checks if the file is a directory
                    printDirectory(newPath);
            }
        }
    }
    closedir(dir);
}