#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>


void goChildGo() {
    printf("Child -> PID: %d, PPID: %d\n", getpid(), getppid());
}

void goParentGo() {
    printf("Parent -> PID: %d, PPID: %d\n", getpid(), getppid());
}


int main() {
    
    int status = 0;
    
    pid_t pid = fork();


    if (pid == 0) {       
            
        atexit(goChildGo);
        sleep(3);
        exit(0);
    } else {
        atexit(goParentGo);
        sleep(3);

        system("./runme what you say!");


        wait(&status);
        if (WIFEXITED(status)) {
            printf("Child Exited Normally\n");
        }   

    }




    

    

    


    


}