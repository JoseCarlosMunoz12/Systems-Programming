#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>



int main() {
   pid_t var = getpid();

    pid_t var2 = getppid();

    printf("PID: %d PPID: %d\n\n",var, var2);

    fflush(NULL);
        
    system("./runme what you say!");
    printf("what");

}