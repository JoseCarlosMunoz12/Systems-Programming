#include <stdlib.h>
#include <stdio.h>

#include <unistd.h>


int main() {
    
    pid_t var = getpid();

    printf("%d\n",var);


}