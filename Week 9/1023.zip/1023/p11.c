#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>





int main() {
    
    int status = 0;
    
    printf("PID: %d, PPID: %d\n", getpid(), getppid());

    uid_t realID = getuid();
    uid_t effID = geteuid();

    printf("UserID: %d Effective ID: %d\n",getuid(), geteuid());

    struct passwd *ps;

    ps = getpwuid(effID);

    if (ps != NULL) {
        printf("UserID: %s (%d)\n",ps->pw_name,ps->pw_uid);
    }

}