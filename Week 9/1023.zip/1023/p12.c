#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>



void printUIDDetails() {
    //printf("PID: %d, PPID: %d\n", getpid(), getppid());

    uid_t realID = getuid();
    uid_t effID = geteuid();

    printf("UserID: %d Effective ID: %d\n",getuid(), geteuid());

    struct passwd *ps;

    ps = getpwuid(effID);

    if (ps != NULL) {
        printf("UserID: %s (%d)\n",ps->pw_name,ps->pw_uid);
    }
}

int main(int argc, char *argv[]) {


    if (argc < 2) {
        printf("Usage:\n");
        printf("    %s <pid 2 change to> ",argv[0]);
        exit(-1);
    }
    
    int newpid = atoi(argv[1]);

    printUIDDetails();

    printf("Switching to new UID: %d\n",newpid);

    int go = seteuid(newpid);

    printf("Switching to new UID: %d : Result: %d\n",newpid,go);

    printUIDDetails();

    
    

}