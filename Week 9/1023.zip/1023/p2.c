#include <stdlib.h>
#include <stdio.h>

#include <unistd.h>


int main() {
    
    pid_t var = getpid();

    pid_t var2 = getppid();

    printf("PID: %d PPID: %d\n",var, var2);


}