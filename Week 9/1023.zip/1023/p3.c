#include <stdlib.h>
#include <stdio.h>

#include <unistd.h>

extern char **environ;

int main() {
    
    pid_t var = getpid();

    pid_t var2 = getppid();

    printf("PID: %d PPID: %d\n",var, var2);

    printf("\nEnvironment Variables:\n");

    for (char ** ptr = environ; *ptr !=0 ; ptr++) {
        printf("%s\n",*ptr);
    }


}