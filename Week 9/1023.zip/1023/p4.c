#include <stdlib.h>
#include <stdio.h>

#include <unistd.h>

extern char **environ;

int main(int argc, char * argv[]) {
    
    pid_t var = getpid();

    pid_t var2 = getppid();

    printf("PID: %d PPID: %d\n",var, var2);

    printf("\nEnvironment Variables:\n");

    for (char ** ptr = environ; *ptr !=0 ; ptr++) {
        printf("%s\n",*ptr);
    }

    printf("\nCommand Line Arguments:\n");

    for (int i=0; i<argc; i++) {
        printf("%s\n", argv[i]);
    }



}