#include <stdlib.h>
#include <stdio.h>

#include <unistd.h>



int main() {
    
    pid_t var = getpid();

    pid_t var2 = getppid();

    printf("PID: %d PPID: %d\n",var, var2);

    fflush(NULL);

    sleep(5);
    
    int exitcode = execl("./runme","say","what","you","want", NULL);

    printf("%d\n",exitcode);


}