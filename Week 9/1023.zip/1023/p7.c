#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>



int main() {
    
    int status = 0;

    pid_t pid = fork();

    pid_t var = getpid();

    pid_t var2 = getppid();

    

    if (pid == 0) {       
        printf("Child!\n"); 
        printf("PID == 0\n");
        printf("PID: %d PPID: %d\n",var, var2);
    } else {
        printf("Parent\n");
        printf("PID != 0\n");
        printf("PID: %d PPID: %d\n",var, var2);
        wait(&status);
        if (WIFEXITED(status)) {
            printf("Child Exited Normally\n");
        }
    }


    //int exitcode = execl("./runme","say","what","you","want", NULL);

    //printf("%d\n",exitcode);


}