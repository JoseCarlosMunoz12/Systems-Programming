#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>



int main() {
    
    int status = 0;

    int x = 46;

    for (int i=0; i<3; i++) {
        //fork
        pid_t pid = fork();

        pid_t var = getpid();

        pid_t var2 = getppid();

        if (pid == 0) {       
            
            x = x - 5;
            printf("Child -> pid == %d -> PID: %d, PPID: %d -> X: %d\n", pid, var, var2, x);

            sleep(3);
            exit(0);
        } else {
            x = x + 10;
            printf("Parent  -> pid == %d -> PID: %d, PPID: %d -> X: %d\n", pid, var, var2, x);
           

        }


    }

    for (int i=0; i<3; i++) {
        wait(&status);
        if (WIFEXITED(status)) {
            printf("Child Exited Normally\n");
        }
    }


    

    

    


    //int exitcode = execl("./runme","say","what","you","want", NULL);

    //printf("%d\n",exitcode);


}