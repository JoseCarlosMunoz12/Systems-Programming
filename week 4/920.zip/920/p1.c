#include <stdio.h>

#define SIZE 10

int main() {


    int array[SIZE];

    return 0;
}