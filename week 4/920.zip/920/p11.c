#include <stdio.h>

#define SIZE 10

int main() {


    int a = 3;

    printf("a = %ld\n",&a);


    return 0;
}