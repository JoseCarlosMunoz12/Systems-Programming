#include <stdio.h>

#define SIZE 10

int main() {


    int array[SIZE] = {0}; 

    for (int i=0; i<SIZE; i++) { 
        printf("%d\n",array[i]);
    }



    return 0;
}